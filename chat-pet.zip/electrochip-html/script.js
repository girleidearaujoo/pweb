function verificar() {
    if (true) {
        
    }
}